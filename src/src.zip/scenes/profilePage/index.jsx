const ProfilePage = () => {
  return <div>profilepage</div>
};

export default ProfilePage;